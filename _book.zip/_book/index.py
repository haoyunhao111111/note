import pymysql
import  time

db=pymysql.connect("localhost","root","123456","uek_demo");

db.autocommit(1);
cursor=db.cursor();
cursor.execute("insert into hhh (name) values ('kkkkk')");

